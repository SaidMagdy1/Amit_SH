/*
 * LoginSystem.h
 *
 *  Created on: 15 Feb 2022
 *      Author: Dell
 */

#ifndef APP_LOGINSYSTEM_H_
#define APP_LOGINSYSTEM_H_


void Auto_AIR_COND_CONTROL(u8 Copy_u8LowerLimit,u8 Copy_u8UpperLimit);
void ServoMotor_Door(u8 Copy_u8Angle);


#endif /* APP_LOGINSYSTEM_H_ */
