/*
 * ADC_int.h
 *
 *  Created on: Feb 11, 2022
 *      Author: PC
 */

#ifndef ADC_INT_H_
#define ADC_INT_H_




void ADC_Init();
int ADC_Read(char channel);

#endif /* ADC_INT_H_ */
