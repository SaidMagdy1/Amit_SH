/*
 * UART_config.h
 *
 *  Created on: Nov 9, 2021
 *      Author: hamdy
 */

#ifndef MCAL_UART_UART_CONFIG_H_
#define MCAL_UART_UART_CONFIG_H_

#define NEW_LINE	YES	// YES or NO


#endif /* MCAL_UART_UART_CONFIG_H_ */
