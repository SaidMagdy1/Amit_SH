/*
 * AVRMaster.c
 *
 * Created: 19/02/2022 20:03:47
 * Author : Dell
 */ 

#include <avr/io.h>


int main(void)
{
    /* Replace with your application code */
    while (1) 
    {
    }
}

