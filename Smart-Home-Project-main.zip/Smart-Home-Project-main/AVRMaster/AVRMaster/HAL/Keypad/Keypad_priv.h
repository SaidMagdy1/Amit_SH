/*
 * Keypad_priv.h
 *
 *  Created on: Oct 9, 2021
 *      Author: Ahmed El-Gaafrawy
 */

#ifndef KEYPAD_PRIV_H_
#define KEYPAD_PRIV_H_

#define KEYPAD_NOT_PRESSED    0xff

#endif /* KEYPAD_PRIV_H_ */
